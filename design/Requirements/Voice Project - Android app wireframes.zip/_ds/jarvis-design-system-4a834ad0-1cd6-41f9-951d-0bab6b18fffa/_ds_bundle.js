/* @ds-bundle: {"format":3,"namespace":"JarvisDesignSystem_4a834a","components":[{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"SectionHeader","sourcePath":"components/core/SectionHeader.jsx"},{"name":"SignalIcon","sourcePath":"components/core/SignalIcon.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"}],"sourceHashes":{"components/core/Badge.jsx":"8340214b5ee1","components/core/Button.jsx":"cbb541c33787","components/core/Card.jsx":"5fa408ce6b6c","components/core/SectionHeader.jsx":"a893263fe27c","components/core/SignalIcon.jsx":"6f4129e92ca8","components/forms/Input.jsx":"f879d06b4b35","components/forms/Switch.jsx":"fdb17b059df1","components/navigation/Tabs.jsx":"11b4925eed44","ui_kits/console/ArtifactScreen.jsx":"0afaab679587","ui_kits/console/BootScreen.jsx":"6ccfcbcff514","ui_kits/console/ConsoleScreen.jsx":"7f98e9d3bc8f","ui_kits/console/Sidebar.jsx":"f595b98b541d","ui_kits/console/TopBar.jsx":"b94e9ea04705"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.JarvisDesignSystem_4a834a = window.JarvisDesignSystem_4a834a || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Jarvis Badge — mono, uppercase status/label chip.
 * tone: signal | neutral | ok | warn | crit
 */
function Badge({
  tone = 'signal',
  dot = false,
  children,
  style = {},
  ...rest
}) {
  const tones = {
    signal: {
      bg: 'var(--signal-dim)',
      fg: 'var(--signal)',
      dotc: 'var(--signal)'
    },
    neutral: {
      bg: 'rgba(138,155,181,0.12)',
      fg: 'var(--mist)',
      dotc: 'var(--mist)'
    },
    ok: {
      bg: 'var(--ok-dim)',
      fg: 'var(--ok)',
      dotc: 'var(--ok)'
    },
    warn: {
      bg: 'var(--warn-dim)',
      fg: 'var(--warn)',
      dotc: 'var(--warn)'
    },
    crit: {
      bg: 'var(--crit-dim)',
      fg: 'var(--crit)',
      dotc: 'var(--crit)'
    }
  };
  const t = tones[tone] || tones.signal;
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      padding: '3px 8px',
      background: t.bg,
      color: t.fg,
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      fontWeight: 'var(--weight-medium)',
      letterSpacing: '0.12em',
      textTransform: 'uppercase',
      borderRadius: 'var(--radius-xs)',
      lineHeight: 1.4,
      ...style
    }
  }, rest), dot && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: '50%',
      background: t.dotc
    }
  }), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Jarvis Button — dark, precise, signal-cyan primary.
 * Variants: primary (signal fill), secondary (outlined), ghost (bare).
 */
function Button({
  variant = 'primary',
  size = 'md',
  disabled = false,
  type = 'button',
  icon = null,
  children,
  style = {},
  ...rest
}) {
  const sizes = {
    sm: {
      padding: '6px 12px',
      fontSize: 12,
      height: 30
    },
    md: {
      padding: '8px 16px',
      fontSize: 13,
      height: 36
    },
    lg: {
      padding: '11px 22px',
      fontSize: 14,
      height: 44
    }
  };
  const s = sizes[size] || sizes.md;
  const base = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    height: s.height,
    padding: s.padding,
    fontSize: s.fontSize,
    fontFamily: 'var(--font-sans)',
    fontWeight: 'var(--weight-medium)',
    letterSpacing: '0.005em',
    borderRadius: 'var(--radius-sm)',
    border: '1px solid transparent',
    cursor: disabled ? 'not-allowed' : 'pointer',
    opacity: disabled ? 0.45 : 1,
    transition: 'background var(--dur-fast) var(--ease-out), border-color var(--dur-fast) var(--ease-out), box-shadow var(--dur-fast) var(--ease-out), transform var(--dur-fast) var(--ease-out)',
    whiteSpace: 'nowrap',
    userSelect: 'none'
  };
  const variants = {
    primary: {
      background: 'var(--signal)',
      color: '#06121A',
      borderColor: 'var(--signal)',
      fontWeight: 'var(--weight-semibold)'
    },
    secondary: {
      background: 'transparent',
      color: 'var(--frost)',
      borderColor: 'var(--line-2)'
    },
    ghost: {
      background: 'transparent',
      color: 'var(--mist)',
      borderColor: 'transparent'
    }
  };
  const [hover, setHover] = React.useState(false);
  const [press, setPress] = React.useState(false);
  const hoverStyle = !disabled && hover ? {
    primary: {
      background: 'var(--signal-deep)',
      borderColor: 'var(--signal-deep)',
      boxShadow: 'var(--glow-md)'
    },
    secondary: {
      borderColor: 'var(--line-glow)',
      background: 'var(--surface-hover)'
    },
    ghost: {
      color: 'var(--frost)',
      background: 'var(--surface-hover)'
    }
  }[variant] : {};
  const pressStyle = !disabled && press ? {
    transform: 'translateY(1px) scale(0.99)'
  } : {};
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    disabled: disabled,
    style: {
      ...base,
      ...variants[variant],
      ...hoverStyle,
      ...pressStyle,
      ...style
    },
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setPress(false);
    },
    onMouseDown: () => setPress(true),
    onMouseUp: () => setPress(false)
  }, rest), icon, children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Jarvis Card — dark container with hairline border. Optional mono kicker
 * label and accent border glow.
 */
function Card({
  label,
  accent = false,
  hover = false,
  children,
  style = {},
  ...rest
}) {
  const [hovered, setHovered] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", _extends({
    onMouseEnter: () => hover && setHovered(true),
    onMouseLeave: () => hover && setHovered(false),
    style: {
      background: 'var(--bg-card)',
      border: `1px solid ${accent ? 'var(--line-glow)' : 'var(--line)'}`,
      borderRadius: 'var(--radius-md)',
      padding: 'var(--space-6)',
      transition: 'border-color var(--dur-base) var(--ease-out), box-shadow var(--dur-base) var(--ease-out)',
      ...(hovered ? {
        borderColor: 'var(--line-glow)',
        boxShadow: 'var(--glow-md)'
      } : {}),
      ...style
    }
  }, rest), label && /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      letterSpacing: '0.18em',
      textTransform: 'uppercase',
      color: 'var(--signal)',
      marginBottom: 'var(--space-3)'
    }
  }, label), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/SectionHeader.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Jarvis SectionHeader — signature numbered header: mono number, title,
 * and a hairline rule filling the remaining width.
 */
function SectionHeader({
  num,
  title,
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      ...style
    }
  }, rest), num != null && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      color: 'var(--signal)',
      letterSpacing: '0.05em'
    }
  }, num), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 18,
      fontWeight: 'var(--weight-semibold)',
      letterSpacing: '-0.01em',
      color: 'var(--frost)'
    }
  }, title), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      height: 1,
      background: 'var(--line)'
    }
  }));
}
Object.assign(__ds_scope, { SectionHeader });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/SectionHeader.jsx", error: String((e && e.message) || e) }); }

// components/core/SignalIcon.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Jarvis SignalIcon — thin 1.5px stroke icons (Lucide-derived geometry),
 * sized in em-ish px, currentColor stroke. Curated set covering the glyphs
 * the Jarvis surfaces use. Extend PATHS as needed.
 */
const PATHS = {
  'arrow-right': /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
    d: "M5 12h14"
  }), /*#__PURE__*/React.createElement("path", {
    d: "m12 5 7 7-7 7"
  })),
  'arrow-up-right': /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
    d: "M7 17 17 7"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M7 7h10v10"
  })),
  'chevron-right': /*#__PURE__*/React.createElement("path", {
    d: "m9 18 6-6-6-6"
  }),
  'chevron-down': /*#__PURE__*/React.createElement("path", {
    d: "m6 9 6 6 6-6"
  }),
  search: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("circle", {
    cx: "11",
    cy: "11",
    r: "8"
  }), /*#__PURE__*/React.createElement("path", {
    d: "m21 21-4.3-4.3"
  })),
  plus: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
    d: "M5 12h14"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M12 5v14"
  })),
  check: /*#__PURE__*/React.createElement("path", {
    d: "M20 6 9 17l-5-5"
  }),
  x: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
    d: "M18 6 6 18"
  }), /*#__PURE__*/React.createElement("path", {
    d: "m6 6 12 12"
  })),
  activity: /*#__PURE__*/React.createElement("path", {
    d: "M22 12h-4l-3 9L9 3l-3 9H2"
  }),
  layers: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
    d: "m12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83Z"
  }), /*#__PURE__*/React.createElement("path", {
    d: "m6.08 9.5-3.49 1.59a1 1 0 0 0 0 1.81l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9a1 1 0 0 0 0-1.82L17.92 9.5"
  })),
  cpu: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("rect", {
    width: "16",
    height: "16",
    x: "4",
    y: "4",
    rx: "2"
  }), /*#__PURE__*/React.createElement("rect", {
    width: "6",
    height: "6",
    x: "9",
    y: "9",
    rx: "1"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M15 2v2M15 20v2M2 15h2M2 9h2M20 15h2M20 9h2M9 2v2M9 20v2"
  })),
  zap: /*#__PURE__*/React.createElement("path", {
    d: "M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z"
  }),
  circle: /*#__PURE__*/React.createElement("circle", {
    cx: "12",
    cy: "12",
    r: "9"
  }),
  'alert-triangle': /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
    d: "m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M12 9v4M12 17h.01"
  })),
  settings: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
    d: "M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2Z"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "12",
    cy: "12",
    r: "3"
  }))
};
function SignalIcon({
  name,
  size = 16,
  strokeWidth = 1.5,
  style = {},
  ...rest
}) {
  const glyph = PATHS[name];
  return /*#__PURE__*/React.createElement("svg", _extends({
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: strokeWidth,
    strokeLinecap: "round",
    strokeLinejoin: "round",
    style: {
      display: 'block',
      flexShrink: 0,
      ...style
    },
    "aria-hidden": "true"
  }, rest), glyph || PATHS.circle);
}

/** Names available in the curated set. */
SignalIcon.names = Object.keys(PATHS);
Object.assign(__ds_scope, { SignalIcon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/SignalIcon.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Jarvis Input — dark field with signal focus ring. Optional mono label.
 */
function Input({
  label,
  id,
  prefix = null,
  style = {},
  wrapStyle = {},
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const inputId = id || (label ? `in-${label.replace(/\s+/g, '-').toLowerCase()}` : undefined);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6,
      ...wrapStyle
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: inputId,
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      letterSpacing: '0.12em',
      textTransform: 'uppercase',
      color: 'var(--muted)'
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      background: 'var(--void)',
      border: `1px solid ${focus ? 'var(--line-glow)' : 'var(--line)'}`,
      borderRadius: 'var(--radius-sm)',
      padding: '0 12px',
      height: 38,
      boxShadow: focus ? 'var(--glow-focus)' : 'none',
      transition: 'border-color var(--dur-fast) var(--ease-out), box-shadow var(--dur-fast) var(--ease-out)'
    }
  }, prefix && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--muted)',
      display: 'flex'
    }
  }, prefix), /*#__PURE__*/React.createElement("input", _extends({
    id: inputId,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      flex: 1,
      background: 'transparent',
      border: 'none',
      outline: 'none',
      color: 'var(--frost)',
      fontFamily: 'var(--font-sans)',
      fontSize: 14,
      ...style
    }
  }, rest))));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Jarvis Switch — toggle with signal-cyan on-state and glow.
 */
function Switch({
  checked = false,
  onChange,
  disabled = false,
  label,
  style = {},
  ...rest
}) {
  const toggle = () => {
    if (!disabled && onChange) onChange(!checked);
  };
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 10,
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.45 : 1,
      userSelect: 'none',
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", _extends({
    role: "switch",
    "aria-checked": checked,
    onClick: toggle,
    style: {
      position: 'relative',
      width: 38,
      height: 22,
      borderRadius: 'var(--radius-full)',
      background: checked ? 'var(--signal)' : 'var(--slate-2)',
      border: `1px solid ${checked ? 'var(--signal)' : 'var(--line-2)'}`,
      boxShadow: checked ? 'var(--glow-md)' : 'none',
      transition: 'background var(--dur-base) var(--ease-out), border-color var(--dur-base) var(--ease-out), box-shadow var(--dur-base) var(--ease-out)',
      flexShrink: 0
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: 2,
      left: checked ? 18 : 2,
      width: 16,
      height: 16,
      borderRadius: '50%',
      background: checked ? '#06121A' : 'var(--mist)',
      transition: 'left var(--dur-base) var(--ease-out), background var(--dur-base) var(--ease-out)'
    }
  })), label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      color: 'var(--frost)',
      fontFamily: 'var(--font-sans)'
    }
  }, label));
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Jarvis Tabs — underline tab bar with signal-cyan active indicator.
 * Controlled: pass `value` + `onChange`, items = [{value,label}].
 */
function Tabs({
  items = [],
  value,
  onChange,
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "tablist",
    style: {
      display: 'flex',
      gap: 4,
      borderBottom: '1px solid var(--line)',
      ...style
    }
  }, rest), items.map(it => {
    const active = it.value === value;
    return /*#__PURE__*/React.createElement("button", {
      key: it.value,
      role: "tab",
      "aria-selected": active,
      onClick: () => onChange && onChange(it.value),
      style: {
        position: 'relative',
        background: 'transparent',
        border: 'none',
        cursor: 'pointer',
        padding: '10px 14px',
        marginBottom: -1,
        fontFamily: 'var(--font-sans)',
        fontSize: 13,
        fontWeight: active ? 'var(--weight-semibold)' : 'var(--weight-medium)',
        color: active ? 'var(--frost)' : 'var(--mist)',
        borderBottom: `2px solid ${active ? 'var(--signal)' : 'transparent'}`,
        transition: 'color var(--dur-fast) var(--ease-out)'
      }
    }, it.label);
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// ui_kits/console/ArtifactScreen.jsx
try { (() => {
/* global React */
// Jarvis Console — artifact (PRD) document view. Tabs + structured doc body.
const {
  Tabs,
  Badge,
  Button,
  SignalIcon,
  Card
} = window.JarvisDesignSystem_4a834a;
function Meta({
  label,
  value,
  tone
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 5
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 9,
      letterSpacing: '0.14em',
      textTransform: 'uppercase',
      color: 'var(--muted)'
    }
  }, label), tone ? /*#__PURE__*/React.createElement(Badge, {
    tone: tone,
    dot: true
  }, value) : /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      fontWeight: 500,
      color: 'var(--frost)'
    }
  }, value));
}
function ArtifactScreen({
  onBack
}) {
  const [tab, setTab] = React.useState('framework');
  const sections = {
    framework: {
      h: 'Problem frame',
      body: 'Realtime sync is not a feature — it is a consistency guarantee. We model it as a single source of truth replicated to clients, where every conflict resolves to a deterministic winner. Reframing it this way changes what we build: not faster polling, but a coherent replication layer.',
      points: ['Treat the document as state, not a stream of edits', 'Conflicts resolve deterministically — last-writer-wins is a policy, not a default', 'The mental model is a database, not a chatroom']
    },
    evidence: {
      h: 'Evidence',
      body: 'Three signals converge. Session telemetry shows 38% of multi-user edits collide within a 4s window. Support volume on "lost changes" is up 22% QoQ. And the two largest accounts have each filed it as a renewal blocker.',
      points: ['38% of concurrent edits collide inside 4 seconds', 'Support tickets tagged data-loss up 22% QoQ', 'Two renewal-critical accounts blocked on this']
    },
    recommendation: {
      h: 'Recommendation',
      body: 'Adopt a CRDT-backed replication layer for the document model. It costs us a heavier client and a 6-week migration, but it removes the conflict class entirely rather than narrowing it. The tradeoff is real: bundle size grows ~40KB and offline becomes a first-class path we must support.',
      points: ['CRDT replication removes the conflict class, not just the symptom', 'Cost: +40KB client, 6-week migration, offline becomes first-class', 'Alternative (server-locks) is cheaper but reintroduces latency we just removed']
    },
    implications: {
      h: 'Implications',
      body: 'This touches seven systems. Billing must meter sync separately. The mobile client inherits the offline path. Infra needs a new presence service. Naming the blast radius now is cheaper than discovering it in QA.',
      points: ['Billing meters sync as a distinct line', 'Mobile inherits offline-first as a hard requirement', 'Infra owns a new presence/awareness service']
    }
  };
  const s = sections[tab];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      height: '100%',
      overflowY: 'auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 760,
      margin: '0 auto',
      padding: '32px 40px 80px'
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: onBack,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 7,
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      color: 'var(--mist)',
      fontSize: 12.5,
      fontFamily: 'var(--font-sans)',
      padding: 0,
      marginBottom: 24
    }
  }, /*#__PURE__*/React.createElement(SignalIcon, {
    name: "arrow-right",
    size: 14,
    style: {
      transform: 'rotate(180deg)'
    }
  }), " Back to console"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      letterSpacing: '0.1em',
      color: 'var(--signal)',
      background: 'var(--signal-dim)',
      padding: '3px 8px',
      borderRadius: 3
    }
  }, "SPEC"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      color: 'var(--muted)'
    }
  }, "JRV-204 \xB7 v2.1")), /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: '0 0 10px',
      fontSize: 32,
      fontWeight: 700,
      letterSpacing: '-0.02em',
      color: 'var(--frost)'
    }
  }, "Realtime Sync"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 24px',
      fontSize: 15,
      color: 'var(--mist)',
      lineHeight: 1.6
    }
  }, "A consistency guarantee for collaborative documents \u2014 modeled as replication, not messaging."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 32,
      padding: '18px 0',
      borderTop: '1px solid var(--line)',
      borderBottom: '1px solid var(--line)',
      marginBottom: 28
    }
  }, /*#__PURE__*/React.createElement(Meta, {
    label: "Status",
    value: "At risk",
    tone: "warn"
  }), /*#__PURE__*/React.createElement(Meta, {
    label: "Owner",
    value: "Dean S."
  }), /*#__PURE__*/React.createElement(Meta, {
    label: "Decision by",
    value: "Jun 18"
  }), /*#__PURE__*/React.createElement(Meta, {
    label: "Blast radius",
    value: "7 systems"
  })), /*#__PURE__*/React.createElement(Tabs, {
    value: tab,
    onChange: setTab,
    items: [{
      value: 'framework',
      label: 'Framework'
    }, {
      value: 'evidence',
      label: 'Evidence'
    }, {
      value: 'recommendation',
      label: 'Recommendation'
    }, {
      value: 'implications',
      label: 'Implications'
    }],
    style: {
      marginBottom: 26
    }
  }), /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: '0 0 12px',
      fontSize: 20,
      fontWeight: 600,
      letterSpacing: '-0.01em',
      color: 'var(--frost)'
    }
  }, s.h), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 22px',
      fontSize: 15,
      color: 'var(--mist)',
      lineHeight: 1.7
    }
  }, s.body), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10,
      marginBottom: 30
    }
  }, s.points.map((p, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      gap: 14,
      alignItems: 'flex-start',
      padding: '14px 18px',
      background: 'var(--slate)',
      border: '1px solid var(--line)',
      borderRadius: 6
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: '50%',
      background: 'var(--signal)',
      marginTop: 7,
      flexShrink: 0
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13.5,
      color: 'var(--frost)',
      lineHeight: 1.55
    }
  }, p)))), tab === 'recommendation' && /*#__PURE__*/React.createElement(Card, {
    accent: true,
    label: "The ask",
    style: {
      marginBottom: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 16,
      fontWeight: 600,
      color: 'var(--frost)',
      marginBottom: 6
    }
  }, "Approve the CRDT migration for Q3."), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13.5,
      color: 'var(--mist)',
      lineHeight: 1.6,
      marginBottom: 16
    }
  }, "One ask, one decision. The tradeoffs are named above \u2014 I'm recommending we pay the migration cost now rather than carry the conflict class into two renewals."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    icon: /*#__PURE__*/React.createElement(SignalIcon, {
      name: "check",
      size: 15
    })
  }, "Approve"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary"
  }, "Request changes")))));
}
window.ArtifactScreen = ArtifactScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/console/ArtifactScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/console/BootScreen.jsx
try { (() => {
/* global React */
// Jarvis Console — boot / sign-in. "Jarvis online" entry with a single signal action.
const {
  Button,
  Input,
  SignalIcon
} = window.JarvisDesignSystem_4a834a;
function BootScreen({
  onEnter
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      height: '100%',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 360,
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 56,
      height: 56,
      borderRadius: 14,
      background: 'var(--signal)',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: '#06121A',
      boxShadow: 'var(--glow-md)',
      marginBottom: 22
    }
  }, /*#__PURE__*/React.createElement(SignalIcon, {
    name: "zap",
    size: 28,
    strokeWidth: 2.2
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      letterSpacing: '0.28em',
      color: 'var(--signal)',
      marginBottom: 12
    }
  }, "JARVIS \xB7 ONLINE"), /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: '0 0 10px',
      fontSize: 26,
      fontWeight: 700,
      letterSpacing: '-0.02em',
      color: 'var(--frost)'
    }
  }, "Welcome back."), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 28px',
      fontSize: 14,
      color: 'var(--mist)',
      lineHeight: 1.6
    }
  }, "Authenticate to resume your workspace. Four artifacts are in flight."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 14,
      textAlign: 'left'
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "Operator",
    defaultValue: "dean.sakihama"
  }), /*#__PURE__*/React.createElement(Input, {
    label: "Passphrase",
    type: "password",
    defaultValue: "systems-thinking"
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    style: {
      width: '100%',
      marginTop: 4
    },
    icon: /*#__PURE__*/React.createElement(SignalIcon, {
      name: "arrow-right",
      size: 16
    }),
    onClick: onEnter
  }, "Enter console")), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 22,
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      letterSpacing: '0.1em',
      color: 'var(--muted)'
    }
  }, "SESSION ENCRYPTED \xB7 256-BIT")));
}
window.BootScreen = BootScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/console/BootScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/console/ConsoleScreen.jsx
try { (() => {
/* global React */
// Jarvis Console — dashboard. Stat tiles, the signature 4-step flow, signal feed.
const {
  Card,
  Badge,
  SignalIcon,
  SectionHeader
} = window.JarvisDesignSystem_4a834a;
function StatTile({
  label,
  value,
  delta,
  tone = 'signal'
}) {
  return /*#__PURE__*/React.createElement(Card, {
    style: {
      padding: 18
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      letterSpacing: '0.14em',
      textTransform: 'uppercase',
      color: 'var(--muted)',
      marginBottom: 12
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 30,
      fontWeight: 700,
      letterSpacing: '-0.02em',
      color: 'var(--frost)'
    }
  }, value), delta && /*#__PURE__*/React.createElement(Badge, {
    tone: tone
  }, delta)));
}
function FlowStep({
  num,
  title,
  desc,
  active
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      background: active ? 'var(--signal-wash)' : 'var(--slate)',
      border: `1px solid ${active ? 'var(--line-glow)' : 'var(--line)'}`,
      padding: 18,
      borderRadius: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      color: 'var(--signal)',
      letterSpacing: '0.1em',
      marginBottom: 8
    }
  }, num, " \u2014\u2014"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      fontWeight: 600,
      color: 'var(--frost)',
      marginBottom: 5
    }
  }, title), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--mist)',
      lineHeight: 1.55
    }
  }, desc));
}
const FEED = [{
  icon: 'check',
  tone: 'ok',
  text: 'PRD · Realtime Sync shipped to review',
  time: '12m',
  tag: 'SPEC'
}, {
  icon: 'alert-triangle',
  tone: 'warn',
  text: 'Deck · Q3 Strategy flagged at risk',
  time: '1h',
  tag: 'SLIDES'
}, {
  icon: 'activity',
  tone: 'signal',
  text: 'Status · Platform health rolled up',
  time: '3h',
  tag: 'REPORT'
}, {
  icon: 'layers',
  tone: 'neutral',
  text: 'System map · Billing dependencies updated',
  time: '5h',
  tag: 'MAP'
}];
function ConsoleScreen({
  onOpenArtifact
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '28px 32px',
      overflowY: 'auto',
      height: '100%'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      justifyContent: 'space-between',
      marginBottom: 24
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      letterSpacing: '0.2em',
      textTransform: 'uppercase',
      color: 'var(--signal)',
      marginBottom: 10
    }
  }, "Operations \xB7 June 2026"), /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      fontSize: 30,
      fontWeight: 700,
      letterSpacing: '-0.02em',
      color: 'var(--frost)'
    }
  }, "Good evening, Dean."), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '8px 0 0',
      fontSize: 14,
      color: 'var(--mist)',
      maxWidth: 460
    }
  }, "Four artifacts in flight. One needs a decision before standup.")), /*#__PURE__*/React.createElement(Badge, {
    tone: "ok",
    dot: true
  }, "All systems nominal")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4, 1fr)',
      gap: 16,
      marginBottom: 32
    }
  }, /*#__PURE__*/React.createElement(StatTile, {
    label: "In flight",
    value: "4",
    delta: "+1",
    tone: "signal"
  }), /*#__PURE__*/React.createElement(StatTile, {
    label: "Awaiting decision",
    value: "1",
    delta: "action",
    tone: "warn"
  }), /*#__PURE__*/React.createElement(StatTile, {
    label: "Shipped \xB7 30d",
    value: "18",
    delta: "+22%",
    tone: "ok"
  }), /*#__PURE__*/React.createElement(StatTile, {
    label: "Blast radius",
    value: "7",
    delta: "systems",
    tone: "neutral"
  })), /*#__PURE__*/React.createElement(SectionHeader, {
    num: "01",
    title: "Default structure",
    style: {
      marginBottom: 18
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12,
      marginBottom: 34
    }
  }, /*#__PURE__*/React.createElement(FlowStep, {
    num: "01",
    title: "Framework",
    desc: "Open with the organizing model. Orient before you inform.",
    active: true
  }), /*#__PURE__*/React.createElement(FlowStep, {
    num: "02",
    title: "Evidence",
    desc: "Data, research, signals. Arrive here \u2014 don't lead."
  }), /*#__PURE__*/React.createElement(FlowStep, {
    num: "03",
    title: "Recommendation",
    desc: "Clear position with acknowledged tradeoffs."
  }), /*#__PURE__*/React.createElement(FlowStep, {
    num: "04",
    title: "Implications",
    desc: "What changes downstream? Who needs to know?"
  })), /*#__PURE__*/React.createElement(SectionHeader, {
    num: "02",
    title: "Signal feed",
    style: {
      marginBottom: 18
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10
    }
  }, FEED.map((f, i) => /*#__PURE__*/React.createElement("button", {
    key: i,
    onClick: onOpenArtifact,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 14,
      textAlign: 'left',
      padding: '14px 18px',
      background: 'var(--slate)',
      border: '1px solid var(--line)',
      borderRadius: 8,
      cursor: 'pointer',
      width: '100%',
      transition: 'border-color 160ms, background 160ms'
    },
    onMouseEnter: e => {
      e.currentTarget.style.borderColor = 'var(--line-glow)';
      e.currentTarget.style.background = 'var(--slate-2)';
    },
    onMouseLeave: e => {
      e.currentTarget.style.borderColor = 'var(--line)';
      e.currentTarget.style.background = 'var(--slate)';
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: `var(--${f.tone === 'neutral' ? 'mist' : f.tone === 'signal' ? 'signal' : f.tone})`,
      display: 'flex'
    }
  }, /*#__PURE__*/React.createElement(SignalIcon, {
    name: f.icon,
    size: 18
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      fontSize: 13.5,
      color: 'var(--frost)'
    }
  }, f.text), /*#__PURE__*/React.createElement(Badge, {
    tone: "neutral"
  }, f.tag), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      color: 'var(--muted)',
      width: 36,
      textAlign: 'right'
    }
  }, f.time), /*#__PURE__*/React.createElement(SignalIcon, {
    name: "chevron-right",
    size: 16,
    style: {
      color: 'var(--muted)'
    }
  })))));
}
window.ConsoleScreen = ConsoleScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/console/ConsoleScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/console/Sidebar.jsx
try { (() => {
/* global React */
// Jarvis Console — left navigation rail. Compact, mono labels, signal active state.
const {
  SignalIcon,
  Badge
} = window.JarvisDesignSystem_4a834a;
function Sidebar({
  active,
  onNavigate
}) {
  const nav = [{
    id: 'console',
    label: 'Console',
    icon: 'activity'
  }, {
    id: 'artifacts',
    label: 'Artifacts',
    icon: 'layers'
  }, {
    id: 'systems',
    label: 'Systems',
    icon: 'cpu'
  }, {
    id: 'signals',
    label: 'Signals',
    icon: 'zap'
  }];
  return /*#__PURE__*/React.createElement("aside", {
    style: {
      width: 224,
      flexShrink: 0,
      background: 'var(--deep)',
      borderRight: '1px solid var(--line)',
      display: 'flex',
      flexDirection: 'column',
      height: '100%'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '20px 18px',
      borderBottom: '1px solid var(--line)',
      display: 'flex',
      alignItems: 'center',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 26,
      height: 26,
      borderRadius: 6,
      background: 'var(--signal)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: '#06121A',
      boxShadow: 'var(--glow-md)'
    }
  }, /*#__PURE__*/React.createElement(SignalIcon, {
    name: "zap",
    size: 15,
    strokeWidth: 2.2
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 700,
      letterSpacing: '-0.01em',
      color: 'var(--frost)'
    }
  }, "JARVIS"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 9,
      letterSpacing: '0.18em',
      color: 'var(--muted)'
    }
  }, "CONSOLE v1.0"))), /*#__PURE__*/React.createElement("nav", {
    style: {
      padding: 10,
      display: 'flex',
      flexDirection: 'column',
      gap: 2,
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 9,
      letterSpacing: '0.16em',
      color: 'var(--muted)',
      padding: '12px 10px 6px'
    }
  }, "WORKSPACE"), nav.map(n => {
    const on = active === n.id;
    return /*#__PURE__*/React.createElement("button", {
      key: n.id,
      onClick: () => onNavigate(n.id),
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 11,
        padding: '9px 10px',
        borderRadius: 6,
        border: 'none',
        cursor: 'pointer',
        background: on ? 'var(--signal-faint)' : 'transparent',
        color: on ? 'var(--frost)' : 'var(--mist)',
        fontFamily: 'var(--font-sans)',
        fontSize: 13,
        fontWeight: on ? 600 : 500,
        textAlign: 'left',
        width: '100%',
        borderLeft: `2px solid ${on ? 'var(--signal)' : 'transparent'}`,
        transition: 'background 120ms, color 120ms'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        color: on ? 'var(--signal)' : 'var(--muted)',
        display: 'flex'
      }
    }, /*#__PURE__*/React.createElement(SignalIcon, {
      name: n.icon,
      size: 16
    })), n.label);
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 14,
      borderTop: '1px solid var(--line)',
      display: 'flex',
      alignItems: 'center',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 30,
      height: 30,
      borderRadius: '50%',
      background: 'var(--slate-2)',
      border: '1px solid var(--line-2)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontSize: 12,
      fontWeight: 600,
      color: 'var(--mist)'
    }
  }, "DS"), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      fontWeight: 600,
      color: 'var(--frost)'
    }
  }, "Dean Sakihama"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 10,
      color: 'var(--muted)'
    }
  }, "Systems \xB7 Online")), /*#__PURE__*/React.createElement(Badge, {
    tone: "ok",
    dot: true
  })));
}
window.Sidebar = Sidebar;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/console/Sidebar.jsx", error: String((e && e.message) || e) }); }

// ui_kits/console/TopBar.jsx
try { (() => {
/* global React */
// Jarvis Console — top bar with mono breadcrumb, search, and primary action.
const {
  SignalIcon,
  Input,
  Button
} = window.JarvisDesignSystem_4a834a;
function TopBar({
  title,
  tag,
  onPrimary,
  primaryLabel = 'New artifact'
}) {
  return /*#__PURE__*/React.createElement("header", {
    style: {
      height: 60,
      flexShrink: 0,
      borderBottom: '1px solid var(--line)',
      background: 'rgba(13,20,34,0.7)',
      backdropFilter: 'blur(8px)',
      display: 'flex',
      alignItems: 'center',
      gap: 16,
      padding: '0 24px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      color: 'var(--muted)',
      letterSpacing: '0.08em'
    }
  }, "JARVIS"), /*#__PURE__*/React.createElement(SignalIcon, {
    name: "chevron-right",
    size: 14,
    style: {
      color: 'var(--muted)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 15,
      fontWeight: 600,
      color: 'var(--frost)',
      letterSpacing: '-0.01em'
    }
  }, title), tag && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      letterSpacing: '0.1em',
      color: 'var(--signal)',
      background: 'var(--signal-dim)',
      padding: '3px 8px',
      borderRadius: 3,
      textTransform: 'uppercase'
    }
  }, tag)), /*#__PURE__*/React.createElement("div", {
    style: {
      width: 220
    }
  }, /*#__PURE__*/React.createElement(Input, {
    prefix: /*#__PURE__*/React.createElement(SignalIcon, {
      name: "search",
      size: 15
    }),
    placeholder: "Search workspace\u2026"
  })), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    icon: /*#__PURE__*/React.createElement(SignalIcon, {
      name: "plus",
      size: 15
    }),
    onClick: onPrimary
  }, primaryLabel));
}
window.TopBar = TopBar;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/console/TopBar.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.SectionHeader = __ds_scope.SectionHeader;

__ds_ns.SignalIcon = __ds_scope.SignalIcon;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.Tabs = __ds_scope.Tabs;

})();
