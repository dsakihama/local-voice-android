# Jarvis Design System

A dark, moody-blue design system for **Jarvis** — a precise, intelligent, systems-thinking aesthetic. Work lives on a near-black void; a single signal-cyan accent is reserved for the one thing that matters on any surface.

> Source: a one-page personal design-system spec (`Jarvis.html`, "Dean Sakihama — Personal Design System", v1.0, June 2026). It defined the palette, type, voice, and artifact standards reproduced and extended here. There was no separate product codebase or Figma file — the aesthetic itself is the brand, so the UI kit (Jarvis Console) is an original demonstration of that aesthetic at full scale.

---

## Content fundamentals — how Jarvis writes

The voice is the **analyst's voice**: precise, structured, confident without overreach. Copy reads like a sharp PM who has already mapped the whole system.

- **Tone:** intelligent, calm, exact. Never breathless, never salesy. "Show the reasoning, not just the conclusion."
- **Person:** mostly impersonal/declarative ("Realtime sync is a consistency guarantee"). Addresses the reader directly when giving guidance ("Orient before you inform"). First person is rare and deliberate ("I'm recommending we pay the cost now").
- **Casing:** Sentence case for prose and headings. **UPPERCASE mono** for labels, tags, kickers, and status (`SPEC`, `AT RISK`, `JARVIS · ONLINE`). Never title-case headings.
- **Sentence length:** short. "Keep sentences as short as the content allows." Fragments are fine for emphasis ("One ask per document.").
- **Structure:** everything follows **Framework → Evidence → Recommendation → Implications**. Name the framework early. Acknowledge tradeoffs explicitly. One ask per document.
- **Numbers & signals:** quantify when it earns clarity ("38% of edits collide", "+22% QoQ", "7 systems"). Don't decorate with stats that carry no decision.
- **Emoji:** none. The only "icons" in copy are mono arrows and section numbers (`01 ——`, `↗`).
- **Vibe:** a HUD readout from a competent machine intelligence. Confident, spare, a little cinematic.

Example specimens:
- Kicker: `OPERATIONS · JUNE 2026`
- Title: "Realtime sync is a consistency guarantee."
- Body: "Three signals converge. Session telemetry shows 38% of multi-user edits collide within a 4s window."
- The signature line: **"This person gets it."**

---

## Visual foundations

**Color.** Dark canvas, cool blues. Backgrounds ramp from `--void #080C14` (page) → `--deep #0D1422` (panels) → `--slate #111826` (cards) → `--slate-2 #161F30` (raised/hover). Text is a frosted ramp: `--frost #E8EFF8` (headings) → `--mist #8A9BB5` (body) → `--muted #4A5875` (meta). The accent is **`--signal #00C8FF` (signal cyan)**, reserved for the single most important element on a surface; `--core #0066FF` is the secondary blue for links. Status uses green/amber/red (`--ok / --warn / --crit`) at low-alpha fills. Imagery, when present, is cool, dark, and high-contrast — never warm.

**Type.** `Inter` for everything human-readable; `JetBrains Mono` for labels, tags, codes, kickers, and anything that should read as a machine signal. Display is Inter 700 at 36px+ with tight `-0.02em` tracking; body is Inter 400/14px at 1.65 line-height. Mono labels are 10–11px, UPPERCASE, `0.12–0.2em` letter-spacing. (Inter is a common UI typeface — it is used here because it is the brand's specified font, not as a default.)

**Spacing.** 4px base grid (`--space-1`=4 … `--space-16`=64). Tight and deliberate; nothing floats arbitrarily. Document max width 960px.

**Corners & borders.** Small, mechanical radii: tags 3px, buttons/inputs 6px, cards 8px, feature panels 10px. Borders are **hairlines** (`--line #1E2D45`, 1px); the accented variant is a low-alpha cyan glow (`--line-glow`). Depth comes from borders and glow, not heavy fills.

**Shadows & glow — glow over shadow.** Drop shadows are low and cool (`--shadow-sm/md/lg`, pure black at low alpha). The signature depth cue is the **signal glow**: focus rings (`--glow-focus`, 3px cyan halo), hover glows (`--glow-md`, 16px cyan bloom), and `--glow-sm` accent outlines. Cards lift by lighting their border to cyan and adding a soft glow — not by casting a big shadow.

**Backgrounds & texture.** Two signature motifs: a barely-there **scan-line overlay** (`--scanlines`, 4px repeating cyan lines at ~1% alpha) and a **corner glow** (`--corner-glow`, radial cyan bleed from top-right). Both are near-subliminal — they read as "HUD" without becoming decoration. No gradients-as-fills, no busy patterns, no photographic backgrounds by default.

**Motion.** Crisp and quick. `--ease-out` (`cubic-bezier(0.16,1,0.3,1)`) for entrances/decelerations; durations 120/200/320ms. No bouncy springs, no long fades. Interactions feel mechanical and immediate.

**Hover states.** Surfaces light their border to `--line-glow` and add `--glow-md`; ghost/secondary buttons tint with `--surface-hover` and brighten text to `--frost`; primary buttons deepen to `--signal-deep` and glow. Hover = "this is alive," signaled with cyan, not with movement.

**Press states.** Buttons nudge down 1px and shrink to `scale(0.99)` — a small, precise mechanical click. No big squish.

**Focus.** Always the cyan focus ring (`--glow-focus`) plus a `--line-glow` border. Visible, deliberate, on-brand.

**Transparency & blur.** Used sparingly for chrome that floats over content: the top bar is `rgba(13,20,34,0.7)` with `backdrop-filter: blur(8px)`. Translucent cyan fills (`--signal-dim / -faint / -wash`) tint badges, active rows, and hover states.

**Cards.** Dark `--slate` fill, 1px `--line` border, 8px radius, ~24px padding, optional signal-cyan mono kicker label. The "one that matters" gets the `accent` glow border. No left-border-accent-only cards, no rounded pill cards.

**Layout rules.** Fixed app chrome (sidebar 224px, top bar 60px) frames a scrolling content area. Numbered section headers (`01  Title  ————`) open every section. Content is left-aligned and grid-driven; centered layouts are reserved for boot screens and big-quote slides.

---

## Iconography

The source brand had **no icon system** — it used Unicode arrows (`↗`, `——`) and mono section numbers as its only glyphs. To give product surfaces real iconography, this system ships **`SignalIcon`**: a curated, thin **1.5px-stroke** set with Lucide-derived geometry, drawn in `currentColor` so it inherits text color (cyan on accents, mist on muted chrome). The thin mechanical stroke matches the precise aesthetic.

- Set: `arrow-right, arrow-up-right, chevron-right, chevron-down, search, plus, check, x, activity, layers, cpu, zap, circle, alert-triangle, settings`.
- **Substitution flag:** the Lucide-derived geometry is a substitution for the absent source icon set. If you need broad coverage, swap in full [Lucide](https://lucide.dev) (same 1.5px stroke style) via CDN and keep `SignalIcon`'s sizing/color conventions.
- **Emoji:** never. **Unicode marks** (`↗`, `——`, `·`) are on-brand as typographic accents, not as UI icons.
- The Jarvis "logo" is a `zap`/bolt glyph in a signal-cyan rounded square with a glow.

---

## Index — what's in this system

**Foundations**
- `styles.css` — root entry point (consumers link this). `@import`s only.
- `tokens/colors.css` · `typography.css` · `spacing.css` · `effects.css` · `fonts.css` — all design tokens + webfont loading.
- `guidelines/*.card.html` — foundation specimen cards (Colors, Type, Spacing, Brand effects).

**Components** (`window.JarvisDesignSystem_4a834a`)
- `components/core/` — `Button`, `Badge`, `Card`, `SectionHeader`, `SignalIcon`.
- `components/forms/` — `Input`, `Switch`.
- `components/navigation/` — `Tabs`.
- Each has a `.jsx`, `.d.ts`, `.prompt.md`, and the directory's `*.card.html` specimen.

**UI kit**
- `ui_kits/console/` — the **Jarvis Console**: boot → dashboard → PRD artifact. `index.html` is the live, click-through app. See its `README.md`.

**Slides**
- `slides/` — `TitleSlide`, `FrameworkSlide`, `BigQuoteSlide` (1280×720, branded).

**Template** (starting point for consuming projects)
- `templates/jarvis-deck/` — **Jarvis Deck**: a copyable title + framework + big-quote presentation on the system. `ds-base.js` loads the tokens and bundle.

**Skill**
- `SKILL.md` — portable skill manifest for use in Claude Code / Agent Skills.

---

## Using it

Link the single stylesheet, then read components off the namespace:

```html
<link rel="stylesheet" href="styles.css" />
<script src="_ds_bundle.js"></script>
<script>
  const { Button, Card, Badge, Tabs, SignalIcon } = window.JarvisDesignSystem_4a834a;
</script>
```

Stay on the rails: dark surfaces, cyan reserved for the one thing that matters, mono for machine signals, glow over shadow, short and structured copy.
