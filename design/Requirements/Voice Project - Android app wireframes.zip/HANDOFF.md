# Local Voice — Hi-Fi Design Handoff

**Project:** Voice Project — Android app wireframes
**Design system:** Jarvis (bound at `_ds/jarvis-design-system-4a834ad0-1cd6-41f9-951d-0bab6b18fffa/`)
**Device target:** Pixel 10 Pro XL — frames are 414×918 screen inside a 444×948 bezel.

## Files
- `Local Voice Wireframes.dc.html` — APPROVED low-fi storyboard (5 sections). **Reference only — do not edit.**
- `Local Voice Hifi.dc.html` — the hi-fi build. All new work goes here.
- `support.js` — DC runtime (do not touch).
- `screenshots/` — working captures.

## What's done & approved
Single DC file. Screens are laid out as labeled frames in horizontal rows on a `#e7e5df` canvas, each frame a 444×948 bezel with a short rationale caption beneath. Four rows are built:

**Row 1 — Happy path (from wireframe Section 01), all 7 approved:**
1. In any app (cyan mic FAB over muted host chat)
2. Pick intent
3. Listening — **waveform bars** (Section 02 option A)
4. Processing — **stepped rail** (Section 03 option C; on-device/privacy, reveals no dictated content)
5. Where to? (target sheet, ranked by frequency; only **installed** apps listed — Claude is the lone cyan pick)
6. Injected (lands in Claude composer, green status toast)
7. Lands in app (settled prompt, cyan Send is the one focal action)

**Row 2 — Clipboard fallback (from wireframe Section 04), all 3 approved:**
1. Can't auto-paste (amber reason, cyan "Copying to clipboard")
2. Tap to paste (bottom sheet, "Paste in Claude" cyan primary)
3. Sticky notification (pinned in shade, never lost)

**Row 3 — Edge states (from wireframe Section 05), all 3 approved:**
1. Mic permission denied (crit-red block, cyan "Open settings", exact settings path + privacy reassurance)
2. No speech detected (warn-amber — recoverable, no work lost; flat-line waveform echoes the Row 1 listening state; cyan "Try again")
3. Processing failed (crit-red; system takes the blame; captured audio preserved in a "saved recording" chip so cyan "Retry transcription" is risk-free)

**Row 4 — Onboarding / first-run (NET-NEW — not in the wireframes), all 4 approved:**
1. Welcome (centered splash; cyan bolt-mic brand mark; value prop; "on-device · no account" stated up front)
2. Why the mic (honest pre-permission priming; 3 plain rows on what the mic does; step rail "1 of 2"; cyan "Allow microphone" + real "Not now")
3. On-device promise (closed-loop diagram: dashed "This device" boundary around voice→engine→text; path to cloud severed in crit-red; offline-test invitation; step "2 of 2")
4. Ready (cyan success check; recap card carries the actual Row 1 FAB with the shared `lvFabGlow` pulse; cyan "Try your first dictation")

**Row 6 — FAB component states (NET-NEW spec strip):** 5 tiles on dark void swatches — Idle (glow + rings), Pressed (1px nudge, scale .97, signal-deep), Dragging (lifted shadow + dock guide + origin ghost), Recording (stop-square glyph, intensified glow), Disabled (muted slate `#161F30`, mic slashed, cyan withdrawn → routes to permission screen). 228px tiles, not device bezels. Engineering spec for the FAB shown in context on Row 1.

**Row 7 — Settings & privacy (NET-NEW, closes the onboarding loop):** single 414×918 frame. Hero = cyan-glow privacy banner ("Everything runs on this device") — the screen's only accent. Sections: PERMISSIONS (Microphone → green GRANTED chip; Auto-paste/accessibility → switch OFF, ties to clipboard fallback), CAPTURE (auto-stop 2.0s, max 60s, language en-US — value+chevron rows), YOUR DATA · ON-DEVICE (on-device learning switch ON = the one live cyan toggle; storage stat 142 transcriptions/38 pairs/1.7 GB; Export JSON; Delete all history in crit-red). Every control maps to a real `AppSettings` field (§5.3) or §8 privacy action. Fits one screen, no internal scroll needed.

**Row 8 — App home (NET-NEW, the missing hub + Settings entry):** single frame. App bar = brand bolt-mic mark + **Settings gear top-right (the entry point that was missing)**. Hero = big 120px cyan dictate mic (single accent, reuses lvFabGlow/lvFabRing) + "Tap to dictate". Today summary line (5 dictations · 94% kept). RECENT section = 3 on-device transcriptions (AI Prompt/Claude, Text/Slack, Notes/Obsidian — spec example text), each with intent·app·time meta. Launcher destination + where onboarding "Ready" routes. NEXT: intent sheet launched from inside the app (existing intent sheet in Row 1 S2 is over a host app).

## Jarvis rules being followed
- Dark void canvas (`#080C14` screen / `#0D1422` panels / `#111826` cards), hairline borders `#1E2D45`.
- **Signal-cyan `#00C8FF` reserved for the single most important element per screen.** Status colors used only for state, never as accent: green `#34D399` (success), amber `#F5B350` (warn/recoverable), red `#F87171` (crit/block).
- Inter for human text, JetBrains Mono UPPERCASE for labels/kickers/status.
- Glow over shadow. No gradients-as-fills (the cyan button gradient is the one sanctioned exception, used consistently for the primary action).
- Centering reserved for boot/welcome/promise surfaces (per Jarvis); all other screens are left-aligned and grid-driven.
- Fonts loaded via Google Fonts `<link>` in `<helmet>` (the DS `@import` alone was unreliable). Note: html-to-image screenshots show serif fallback — the live iframe renders Inter correctly.

## Workflow the user expects
**One screen at a time. Build → show → wait for explicit approval → next.** Never batch. Keep wireframe flow/structure where a wireframe exists; only raise fidelity + apply Jarvis. For net-new flows (e.g. onboarding) state up front that it's being designed fresh from the established hifi conventions.

## Screens from the wireframes NOT yet designed in hi-fi
These are the explicit alternates the wireframes explored but that didn't make the V1 pick. They exist as approved low-fi but have no hi-fi counterpart:

**Listening alternates (wireframe Section 02) — A (bars) shipped; B (orb) NOW BUILT hi-fi as Row 5:**
- **B · Pulsing orb** — ✅ BUILT (Row 5). Two frames: B1 full-size in-app (drop-in for the bars, same chrome/REC/auto-stop hint) + B2 glanceable lock screen (~84px orb under a big clock, proving it scales down where bars fail). Breathing core + expanding ripple rings, cyan-only. Keyframes `lvOrbBreath` / `lvOrbRipple` / `lvOrbGlow`.
- **C · Live transcript** — words land as you speak. Max confidence, but puts dictated content on screen (fights the "nothing visible" privacy rule) and exposes raw STT errors. Flagged ⚠ PRIVACY. DECISION: not building — left as documented road-not-taken (conflicts with the on-device promise onboarding makes).

**Processing alternates (wireframe Section 03) — only option C (stepped rail) was built:**
- **A · Just a spinner** — dead simple, zero content shown. Risk: a 9s spinner feels like a black box.
- **B · Raw → clean reveal** — shows the cleanup transformation live. Delightful and trust-building, but shows full content (privacy) and ugly mid-flight STT errors. Flagged ⚠ PRIVACY in the wireframe.

## Recommendation — where to go next
1. **Skip the privacy-flagged alternates (Listening C, Processing B).** They directly contradict the on-device/"nothing visible" principle this product now states explicitly in onboarding. Building them hi-fi would send a mixed message; leave them as documented low-fi roads-not-taken.
2. **Highest value next: a settings / privacy-controls screen.** Onboarding now makes strong promises (on-device, revoke anytime, recordings discarded). There is no hi-fi surface where the user can actually see/exercise those controls — mic permission status, intent defaults, clipboard-fallback toggle, "revoke access." This closes the loop the onboarding opens and is genuinely net-new value, not a redundant alternate.
3. **Then, if small-surface coverage matters: Listening B (orb).** It's the one remaining alternate with no privacy conflict and a real use case (lock-screen / wearable / glanceable), so it's the only alternate worth a hi-fi take.
4. **Defer Processing A (bare spinner)** — the shipped stepped rail already covers the on-device processing moment better; a bare spinner adds little.

Suggested order: **Settings/privacy controls → (optional) Listening B orb.** Confirm with the user before starting, and keep the one-screen-at-a-time cadence.
